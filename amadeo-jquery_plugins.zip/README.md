#
MÓDULO 10│Plugins jQuery
#
A entrega deste exercício
consiste em:

• Crie um formulário de cadastro, este formulário
deverá conter os campos: nome completo, e-mail,
telefone, CPF, endereço completo e CEP;

• Utilize o plugin jQuery Mask Plugin para aplicar
máscara aos campos CPF, telefone e CEP;

#